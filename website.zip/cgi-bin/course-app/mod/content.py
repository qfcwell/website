
if_ie987='<!--[if IE 9]>\n<link rel="stylesheet" media="screen" href="../css/style.ie9.css"/>\n<![endif]-->\n<!--[if IE 8]>\n<link rel="stylesheet" media="screen" href="../../css/style.ie8.css"/>\n<![endif]-->\n<!--[if lt IE 9]>\n<script src="../../js/plugins/css3-mediaqueries.js"></script>\n<![endif]-->'


head_left='<div class="left">\n<h1 class="logo"><span>CAPOL华阳国际</span></h1>\n<span class="slogan">培训课程管理.DEMO</span><br clear="all" />\n</div><!--left-->\n'
head_right="""<div class="right">
                    <!--<div class="notification"><a class="count"href="notifications.html"><span>9</span></a></div>-->
                    <div class="userinfo">
                        <img src="../../images/thumbs/avatar.png" alt="" />
                        <span>
                            管理员
                        </span>
                    </div>
                    <!--userinfo-->
                    <div class="userinfodrop">
                        <div class="avatar">
                            <a href="">
                                <img src="../../images/thumbs/avatarbig.png" alt="" />
                            </a>
                            <div class="changetheme">
                                Change theme:
                                <br/>
                                <a class="default">
                                </a>
                                <a class="blueline">
                                </a>
                                <a class="greenline">
                                </a>
                                <a class="contrast">
                                </a>
                                <a class="custombg">
                                </a>
                            </div>
                        </div>
                        <!--avatar-->
                        <div class="userdata">
                            <h4>
                                管理员
                            </h4>
                            <span class="email">
                                youremail@yourdomain.com
                            </span>
                            <ul>
                                <li>
                                    <a href="editprofile.html">
                                        Edit Profile
                                    </a>
                                </li>
                                <li>
                                    <a href="accountsettings.html">
                                        Account Settings
                                    </a>
                                </li>
                                <li>
                                    <a href="help.html">
                                        Help
                                    </a>
                                </li>
                                <li>
                                    <a href="index.html">
                                        Sign Out
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <!--userdata-->
                    </div>
                    <!--userinfodrop-->
                </div>
                <!--right-->"""



div_dataTables_length="""<div class="dataTables_length" style="padding:5px">     
						<ul class="buttonlist">
                            <li>
                                <a href="" class="btn btn_info">
                                    <span>
                                        打开
                                    </span>
                                </a>
                                <a href="" class="btn btn_info">
                                    <span>
                                        打开路径
                                    </span>
                                </a>
                                <a href="" class="btn btn_info">
                                    <span>
                                        获取路径
                                    </span>
                                </a>
                            </li>
                            <li>
                                <a href="" class="btn btn_info">
                                    <span>
                                        复制新增
                                    </span>
                                </a>
                                <a href="" class="btn btn_info">
                                    <span>
                                        重命名
                                    </span>
                                </a>
                                <a href="" class="btn btn_trash">
                                    <span>
                                        删除
                                    </span>
                                </a>
                            </li>
                            <li>
                                <a href="" class="btn btn_info">
                                    <span>
                                        上传
                                    </span>
                                </a>
                                <a href="" class="btn btn_info">
                                    <span>
                                        下载
                                    </span>
                                </a>
                                <a href="" class="btn btn_info">
                                    <span>
                                        发送
                                    </span>
                                </a>
                            </li>
                        </ul>
                    
                            
							
                        </div>"""

p_end="""<p align="center" valign="middle"> <a target="_blank" href="http://www.miitbeian.gov.cn/">备案号：&nbsp; 粤ICP备17055037号  </a><br/>/p>
"""
